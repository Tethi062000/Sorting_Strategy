package SortingStrategy;

interface SortingStrategy {
    void sort(int[] array);
}