package SortingStrategy;
import java.util.Arrays;


public class Main {
    public static void main(String[] args) {
        int[] data = { 22, 45, 3, 8, 18 };
        
        SortingContext context = new SortingContext();
        
        int[] insertionSortData = { 22, 45, 3, 8, 18};
        context.setStrategy(new InsertionSort());
        context.performSort(insertionSortData);
        System.out.println("Sorted using Insertion Sort: " + Arrays.toString(insertionSortData));

        int[] mergeSortData = { 22, 45, 3, 8, 18 };
        context.setStrategy(new MergeSort());
        context.performSort(mergeSortData);
        System.out.println("Sorted using Merge Sort: " + Arrays.toString(mergeSortData));
    }
}

